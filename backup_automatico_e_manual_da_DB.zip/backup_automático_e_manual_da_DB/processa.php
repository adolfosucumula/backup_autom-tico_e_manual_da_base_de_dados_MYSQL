<?php
session_start();
ob_start();
//Receber os dados do formulário

//-------------- Caso os dados venham de um formulário executa o primeiro código ------------------------//
if(isset($_POST['servidor']) && isset($_POST['dbname']) && isset($_POST['senha']) && isset($_POST['usuario'])){
	$servidor = trim(strip_tags($_POST['servidor']))
	$usuario = trim(strip_tags($_POST['usuario']));
	$senha = trim(strip_tags($_POST['senha']));
	$dbname = trim(strip_tags($_POST['dbname']));

	$servidor = addslashes(htmlspecialchars($servidor));
	$usuario = addslashes(htmlspecialchars($usuario));
	$senha = addslashes(htmlspecialchars($senha));
	$dbname = addslashes(htmlspecialchars($dbname));

	if(!empty($dbname) && !empty($senha) && !empty($usuario) && !empty($servidor)){
		//Criar a conexao com BD
		$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);

		//Incluir o arquivo que gerar o backup
		include_once("gerar_backup.php");

	}
}else{
//-------------------- caso nenhum parámetro é recebido a partir de um formulário o código pode ser adaptado para ser executado de forma automática com os dados padronizados. Neste caso este será o arquivo que de ser sempre chamado de alguma página qualquer 	
	$servidor = "localhost";
	$usuario = "root";
	$senha = "123";
	$dbname = "teste";

	//Criar a conexao com BD
$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);

//Incluir o arquivo que gera o backup
include_once("gerar_backup.php");

}



header("Location: ../views/configuracoes.php");


